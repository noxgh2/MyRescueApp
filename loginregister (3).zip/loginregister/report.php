<?php
require "DataBase.php";
$db = new DataBase();
if (isset($_POST['Type']) && isset($_POST['Description']) && isset($_POST['Image']) && isset($_POST['username']) ){
    if ($db->dbConnect()) {
      if ($db->report("report", $_POST['Type'], $_POST['Description'], $_POST['Image'],$_POST['username'])){
        echo "Your Report Was Received";
      }else echo "You need to complete all required fields";
    } else echo "Error: Database connection";
} else echo "All fields are required";
?>
