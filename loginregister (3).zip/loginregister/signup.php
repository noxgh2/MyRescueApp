<?php
require "DataBase.php";
$db = new DataBase();

if (isset($_POST['first_name']) && isset($_POST['last_name']) && isset($_POST['National_ID']) && isset($_POST['username']) && isset($_POST['phone_number']) && isset($_POST['password'])) {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $National_ID = $_POST['National_ID'];
    $username = $_POST['username'];
    $phone_number = $_POST['phone_number'];
    $password = $_POST['password'];


    // Validate phone number length
    if (strlen($phone_number) !== 10) {
        echo "The phone number must be exactly 10 digits";
    }else if(strlen($National_ID) !== 10) {
        echo "The National ID/Iqama must be exactly 10 digits";
      } else {
          // Validate password complexity
          $uppercase = preg_match('@[A-Z]@', $password);
          $lowercase = preg_match('@[a-z]@', $password);
          $number = preg_match('@[0-9]@', $password);
          $specialChars = preg_match('@[^\w]@', $password);

          if (!$uppercase || !$lowercase || !$number || !$specialChars || strlen($password) < 8) {
              echo 'Password should be at least 8 characters in length and include at least one uppercase letter, one number, and one special character.';
          } else {
              // Database connection check
              if ($db->dbConnect()) {
                  // Attempt to sign up the user
                  if ($db->signUp("users", $first_name, $last_name, $National_ID, $username, $phone_number, $password)) {
                      echo "Sign Up Success";
                  } else {
                      echo "Sign Up Failed";
                  }
              } else {
                  echo "Error: Database connection";
              }
          }
      }
  } else {
      echo "All fields are required";
  }
  ?>
