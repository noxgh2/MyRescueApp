<?php
require "DataBase.php";
$db = new DataBase();
if (isset($_POST['Gender']) && isset($_POST['Dieases']) &&isset($_POST['Medications'])&&isset($_POST['username'])) {
    if ($db->dbConnect()) {
        if ($db->updatehealthRecord("health_record", $_POST['Gender'], $_POST['Dieases'], $_POST['Medications'],$_POST['username'])) {
            echo "Your health record has been successfully updated";
        } else echo "You need to complete all required fields";
    } else echo "Error: Database connection";
} else echo "All fields are required";
?>
