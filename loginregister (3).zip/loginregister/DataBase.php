<?php
require "DataBaseConfig.php";

class DataBase
{
    public $connect;
    public $data;
    private $sql;
    protected $servername;
    protected $username;
    protected $password;
    protected $databasename;

    public function __construct()
    {
        $this->connect = null;
        $this->data = null;
        $this->sql = null;
        $dbc = new DataBaseConfig();
        $this->servername = $dbc->servername;
        $this->username = $dbc->username;
        $this->password = $dbc->password;
        $this->databasename = $dbc->databasename;
    }

    function dbConnect()
    {
        $this->connect = mysqli_connect($this->servername, $this->username, $this->password, $this->databasename);
        return $this->connect;
    }

    function prepareData($data)
    {
        return mysqli_real_escape_string($this->connect, stripslashes(htmlspecialchars($data)));
    }

    function logIn($table, $username, $password)
    {
        $username = $this->prepareData($username);
        $password = $this->prepareData($password);
        $this->sql = "select * from " . $table . " where username = '" . $username . "'";
        $result = mysqli_query($this->connect, $this->sql);
        $row = mysqli_fetch_assoc($result);
        if (mysqli_num_rows($result) != 0) {
            $dbusername = $row['username'];
            $dbpassword = $row['password'];
            if ($dbusername == $username && password_verify($password, $dbpassword)) {
                $login = true;
            } else $login = false;
        } else $login = false;

        return $login;
    }

    function signUp($table, $first_name,$last_name,$National_ID, $username,$phone_number,  $password)
    {
        $first_name = $this->prepareData($first_name);
        $last_name = $this->prepareData($last_name);
        $National_ID = $this->prepareData($National_ID);
        $username = $this->prepareData($username);
        $phone_number = $this->prepareData($phone_number);
        $password = $this->prepareData($password);

        $password = password_hash($password, PASSWORD_DEFAULT);
        $this->sql =
            "INSERT INTO " . $table . " (first_name, last_name, National_ID, username, phone_number, password ) VALUES ('" . $first_name . "','" . $last_name . "','" . $National_ID . "','"
            . $username . "','" . $phone_number . "','" . $password . "')";
        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }
    function healthRecord($table, $Gender,	$Dieases,	$Medications,$username)
    {
        $Gender = $this->prepareData($Gender);
        $Dieases = $this->prepareData($Dieases);
        $Medications = $this->prepareData($Medications);
          $username = $this->prepareData($username);

        $this->sql =
        "INSERT INTO " . $table . " (Gender, Dieases, Medications, username) VALUES ('" . $Gender . "','" . $Dieases . "','" . $Medications ."','" . $username ."')";
          if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

    function updatehealthRecord($table, $Gender, $Dieases,	$Medications,$username)
   {
       $Gender = $this->prepareData($Gender);
       $Dieases = $this->prepareData($Dieases);
       $Medications = $this->prepareData($Medications);
         $username = $this->prepareData($username);

       $this->sql ="Update " . $table .  " SET Gender='$Gender',Dieases='$Dieases',Medications='$Medications' where username = '" . $username . "'";

         if (mysqli_query($this->connect, $this->sql)) {
           return true;
       } else return false;
   }
    function EmergencyContacts($table,$Name, $Relative_Relation, $phone,$username)
    {
        $Name = $this->prepareData($Name);
        $Relative_Relation = $this->prepareData($Relative_Relation);
        $phone = $this->prepareData($phone);
  $username = $this->prepareData($username);

        $this->sql =
            "INSERT INTO " . $table . " (Name, Relative_Relation, phone,username) VALUES ('" . $Name . "','" . $Relative_Relation . "','" . $phone ."','" . $username ."')";
        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }
    function updateEmergencyContacts($table,$Name, $Relative_Relation, $phone,$username)
        {
            $Name = $this->prepareData($Name);
            $Relative_Relation = $this->prepareData($Relative_Relation);
            $phone = $this->prepareData($phone);
      $username = $this->prepareData($username);

            $this->sql =
               $this->sql ="Update " . $table .  " SET Name='$Name',Relative_Relation='$Relative_Relation',phone='$phone' where username = '" . $username . "'";
            if (mysqli_query($this->connect, $this->sql)) {
                return true;
            } else return false;
        }

     function report($table,$Type, $Description, $Image,$username)
    {
        $Type = $this->prepareData($Type);
        $Description = $this->prepareData($Description);
        $Image = $this->prepareData($Image);
 $username = $this->prepareData($username);
        $this->sql =
        "INSERT INTO " . $table . " (Type, Description, Image,username) VALUES ('" . $Type . "','" . $Description . "','" . $Image ."','" . $username ."')";
        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

    function checkHealthRecord($table,$username){
      $username = $this->prepareData($username);
      $this->sql = "select * from " . $table . " where username = '" . $username . "'";
          $result2 = mysqli_query($this->connect, $this->sql);
          $row = mysqli_fetch_assoc($result2);
          if (mysqli_num_rows($result2) != 0) {
                  $exsit = true;
              } else $exsit = false;

          return $exsit;
        }
        function checkEmergencycontact($table,$username){
          $username = $this->prepareData($username);
          $this->sql = "select * from " . $table . " where username = '" . $username . "'";
              $result2 = mysqli_query($this->connect, $this->sql);
              $row = mysqli_fetch_assoc($result2);
              if (mysqli_num_rows($result2) != 0) {
                      $exsit = true;
                  } else $exsit = false;

              return $exsit;
            }
          // Your MySQL connection code here




    function insertUserReport($Report_message){
      $date_time = date("Y-m-d H:i:s");
      $report_exists = false; // You need to implement this check based on your application logic
      $user_exists = false; // You need to implement this check based on your application logic
      $authority_exists = false; // You need to implement this check based on your application logic
      // Check if the referenced records exist before inserting


      // Query to check if the report exists
      $report_query = "SELECT * FROM report WHERE Report_ID = '$Report_ID'";
      $report_result = $conn->query($report_query);
      if ($report_result->num_rows > 0) {
          $report_exists = true;
      }
      // Query to check if the user exists
      $user_query = "SELECT * FROM users WHERE National_ID = '$National_ID'";
      $user_result = $conn->query($user_query);
      if ($user_result->num_rows > 0) {
          $user_exists = true;
      }
      // Query to check if the authority exists
      $authority_query = "SELECT * FROM competent_authority WHERE Authority_Name = '$AuthorityName'";
      $authority_result = $conn->query($authority_query);
      if ($authority_result->num_rows > 0) {
          $authority_exists = true;
      }
      if ($report_exists && $user_exists && $authority_exists) {
        // SQL query to insert data
        $this->sql ="INSERT INTO " . $table . " (Report_message) VALUES ('" . $Report_message . "')";
          if (mysqli_query($this->connect, $this->sql)) {
            return true;
          } else return false;
      }
    }
}
?>
