<?php
require "DataBase.php";
$db = new DataBase();
if (isset($_POST['username'])) {
    if ($db->dbConnect()) {
        if ($db->checkHealthRecord("health_record", $_POST['username'])) {
          echo "Success";
        } else echo "Fail";
    } else echo "Error: Database connection";
} else echo "All fields are required";

?>
