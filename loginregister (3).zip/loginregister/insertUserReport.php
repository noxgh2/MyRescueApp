<?php
require "DataBase.php";
$db = new DataBase();
if (isset($_POST['	Report_message'])&& isset($_POST['Date_Time'])) {
    if ($db->dbConnect()) {
        if ($db->insertUserReport("user_report", $_POST['	Report_message'],$_POST['Date_Time'])){
          echo "Your report summary";
        } else echo "You need to complete all required fields";
    } else echo "Error: Database connection";
} else echo "All fields are required";
?>
