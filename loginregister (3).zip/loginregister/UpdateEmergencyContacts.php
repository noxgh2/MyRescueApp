<?php
require "DataBase.php";
$db = new DataBase();
if (isset($_POST['Name']) && isset($_POST['Relative_Relation']) &&isset($_POST['phone'])&&isset($_POST['username'])) {
    if ($db->dbConnect()) {
        if ($db->updateEmergencyContacts("Emergency_Contacts", $_POST['Name'], $_POST['Relative_Relation'], $_POST['phone'],$_POST['username'])) {
            echo "Your emergency contacts has been successfully updated";
        } else echo "You need to complete all required fields";
    } else echo "Error: Database connection";
} else echo "All fields are required";
?>
